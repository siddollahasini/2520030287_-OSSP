# Linux Process Tree Visualizer

**Problem statement:** Create a tool that displays the hierarchy of running
processes and their parent-child relationships in real time.

**Course:** Operating Systems and Systems Programming (25CS2104E)

A terminal tool written in C for Ubuntu/Linux. No GUI and no external
libraries: process data is read straight from the `/proc` filesystem. Besides
the live tree viewer, each of the six course outcomes (CO1 to CO6) has its own
module with a runnable demo that uses the tool's own processes as the example.

## Setup (Ubuntu + VS Code)

```bash
sudo apt update
sudo apt install build-essential        # gcc + make (skip if installed)
unzip process-tree-visualizer.zip
cd process-tree-visualizer
code .                                  # open in VS Code, then Ctrl+` for the terminal
make                                    # builds ./ptree
```

## The main tool (live process tree)

```bash
./ptree            # live view, refreshes every second, Ctrl+C to quit
./ptree -o         # print the tree once and exit
./ptree -k -d 3    # hide kernel threads, show 3 levels
./ptree -p 1       # only the subtree of PID 1 (systemd)
./ptree -i 2       # refresh every 2 seconds
```

While it is running you can send it signals from another terminal:
`kill -USR1 <pid>` refreshes now, `kill -USR2 <pid>` toggles kernel threads.

Each line shows: name, PID, state, owner, resident memory, thread count.
A green `+` marks a process that appeared since the last refresh; an
`Exited:` line lists processes that finished. State colours: green running,
grey sleeping, yellow disk-wait, red zombie, magenta stopped.

## Course outcomes: what to run for each CO

| CO  | Outcome (from the handout)                              | Command                                  | What it shows |
|-----|---------------------------------------------------------|------------------------------------------|---------------|
| CO1 | OS as a layered service, user/kernel mode, syscalls, shell | `./ptree --layers`                    | Layer diagram; one service reached via libc, raw `syscall()` and `/proc`; cost of a mode switch (measured); shell as a user program (ancestor chain); CPU blocking a user read of kernel memory; journey of a command |
| CO2 | Process control: fork, exec, wait, exit                 | `./ptree --spawn sleep 2`<br>`./ptree --zombie`<br>`./ptree --orphan` | fork copy then exec (same PID, new program); exit status; a real zombie (state Z) and its reaping; an orphan being re-parented |
| CO3 | IPC: pipes, FIFOs, sockets, signals, shared memory      | `./ptree --ipc`                          | Collector/viewer exchange process data over an anonymous pipe, a FIFO, shared memory and a UNIX socket; signals (USR1, STOP/CONT/TERM changing the tree state); process groups and sessions |
| CO4 | Virtual memory: paging, translation, faults, COW        | `./ptree --mem-demo`<br>`./ptree --mem [PID]` | Demand paging (mmap, RAM only on first touch); virtual to physical translation via pagemap; page-fault counts; copy-on-write after fork; SIGSEGV for NULL and read-only writes; address-space map of any process |
| CO5 | File systems: inodes, VFS, file I/O syscalls            | `./ptree --fs-demo`<br>`./ptree --files [PID]`<br>`./ptree --save f.bin` then `./ptree --load f.bin` | open/write/lseek/read, inode contents, hard vs symbolic link, readdir, mount point and fs type, buffered vs unbuffered I/O, mmap I/O, error handling; open FDs of a process mapped to inodes; binary snapshot save and validated replay |
| CO6 | Concurrency: threads, mutex, condvar, semaphore, deadlock | `./ptree --race-demo`<br>`./ptree --threads`<br>`./ptree --deadlock-demo` | Lost updates without a lock vs mutex vs atomic; bounded-buffer parallel `/proc` scan (mutex + 2 condition variables + counting semaphore); deadlock detected by timeout and fixed by lock ordering |

Run everything in order with `./ptree --demo-all` (or `make demo`).

## Live demo for the viva

Terminal 1: `./ptree -k`  
Terminal 2: `./demo.sh` (creates and removes child processes; or open and close
`gedit`/`firefox`). You will see `+` marks appear and `Exited:` entries.

## Project structure

```
process-tree-visualizer/
├── Makefile
├── demo.sh               creates a changing process tree for the live demo
├── README.md
└── src/
    ├── ptree.h           shared declarations and module map
    ├── main.c            command line + live refresh loop + signal handling
    ├── proc.c            CORE   read /proc, build the parent-child tree
    ├── viewer.c          CORE   draw the tree in the terminal
    ├── co1_layers.c      CO1    layered OS, syscalls, shell
    ├── co2_process.c     CO2    fork / exec / wait / exit, zombie, orphan
    ├── co3_ipc.c         CO3    pipe, FIFO, signals, groups, shm, socket
    ├── co4_memory.c      CO4    paging, page faults, COW, memory errors
    ├── co5_files.c       CO5    inodes, VFS, file I/O, snapshot files
    └── co6_threads.c     CO6    pthreads, mutex, condvar, semaphore, deadlock
```

## How the core works

1. Every numeric directory in `/proc` is a running process.
2. `/proc/<pid>/stat` gives name, state, **PPID** (parent PID) and thread count;
   `/proc/<pid>/status` gives owner and resident memory.
3. All processes are sorted by PID. Each process finds its parent with binary
   search and is linked into first-child / next-sibling lists.
4. A recursive depth-first walk prints the tree with `├──` and `└──` branches.
5. The snapshot is reloaded every N seconds and compared with the previous one
   to find new and exited processes.

## Short viva answers

- **Input / output?** Input: a command such as `./ptree -k`. Output: the process
  tree, refreshed live. The data itself comes from `/proc`.
- **How do you know a parent-child relationship?** Every process stores its
  parent's PID (PPID) in `/proc/<pid>/stat`.
- **Why a zombie?** The child exited but the parent has not called `wait()`, so
  only its process-table entry remains (state Z).
- **What happens to an orphan?** The kernel re-parents it to PID 1 (or to a
  subreaper, which this project uses in `--orphan`).
- **Why are system calls slower than function calls?** They switch from user mode
  to kernel mode (measured by `--layers`).
- **What is copy-on-write?** After `fork()` parent and child share pages; a page is
  copied only when one of them writes (`--mem-demo`).
- **Hard link vs symbolic link?** A hard link is another name for the same inode;
  a symlink is a separate small file holding a path (`--fs-demo`).
- **What causes deadlock and how is it prevented?** Circular wait on locks; fixed
  by acquiring locks in one global order (`--deadlock-demo`).

## Notes

- Linux only (needs `/proc`); works on Ubuntu and on WSL. No `sudo` needed.
  Run `sudo ./ptree --mem-demo` to also see real physical frame numbers.
- Demos create temporary files in `/tmp` and remove them afterwards.
- Memory and thread numbers differ from machine to machine; they are measured
  live, not hard-coded.
