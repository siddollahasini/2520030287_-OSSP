#!/bin/bash
# Creates a small, changing process tree so you can watch ptree react live.
#
#   Terminal 1:  ./demo.sh            (prints its own PID)
#   Terminal 2:  ./ptree -p <PID>     (live tree of just this demo)
#
# New processes appear with a green +, finished ones are listed as "Exited:".

echo "Demo root PID: $$"
echo "In another terminal run:  ./ptree -p $$"
echo "Press Ctrl+C to stop."

trap 'kill 0 2>/dev/null; exit 0' INT TERM

# a permanent branch
( sleep 1000 & sleep 1000 & wait ) &

while true; do
    # a short-lived branch appears ...
    ( sleep 4 & ( sleep 4 & wait ) & wait ) &
    sleep 3
    # ... and a second one a bit later
    ( sleep 3 & wait ) &
    sleep 5
done
