/*
 * co4_memory.c - CO4: virtual memory
 *
 *   --mem [PID]  : address-space layout, memory totals and page-fault counters
 *   --mem-demo   : live experiments on ptree itself
 *        1. demand paging  (mmap gives address space, RAM only on first touch)
 *        2. virtual -> physical translation using /proc/self/pagemap
 *        3. copy-on-write  (fork shares pages until somebody writes)
 *        4. memory errors  (SIGSEGV: unmapped address / permission violation)
 *
 * The TLB lives inside the CPU and cannot be observed from user space, so it
 * is explained in the output instead of measured.
 */
#include "ptree.h"

#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>

static long g_ps;                                   /* page size in bytes */

static long minflt_self(void) {
    struct rusage ru;
    getrusage(RUSAGE_SELF, &ru);
    return ru.ru_minflt;
}

/* statm: size resident shared text lib data dt   (all in pages) */
static int read_statm(const char *who, long *size, long *res, long *shared) {
    char path[64];
    snprintf(path, sizeof path, "/proc/%s/statm", who);
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    int ok = fscanf(f, "%ld %ld %ld", size, res, shared) == 3;
    fclose(f);
    return ok ? 0 : -1;
}

/* ------------------------------------------------------------------ */
/*  --mem PID : inspect any process                                     */
/* ------------------------------------------------------------------ */
int co4_inspect(int pid) {
    banner("CO4", "Address-space layout and paging statistics");
    g_ps = sysconf(_SC_PAGESIZE);
    if (pid <= 0) pid = getpid();

    Proc p;
    if (read_process(pid, &p) != 0) { printf("   PID %d not found\n", pid); return 1; }
    printf("   process %d (%s), page size = %ld bytes\n", pid, p.comm, g_ps);

    char path[64], exe[256] = "";
    snprintf(path, sizeof path, "/proc/%d/exe", pid);
    ssize_t n = readlink(path, exe, sizeof exe - 1);
    if (n > 0) exe[n] = '\0'; else exe[0] = '\0';

    snprintf(path, sizeof path, "/proc/%d/maps", pid);
    FILE *f = fopen(path, "r");
    if (!f) { printf("   cannot read %s (permission denied?)\n", path); return 1; }

    section("Virtual address space (/proc/PID/maps) - lowest to highest address");
    printf("   %-25s %-5s %9s  %s\n", "address range", "perm", "size", "region");

    unsigned long code = 0, heap = 0, stack = 0, filedata = 0, anon = 0, kern = 0;
    int lines = 0, regions = 0;
    char line[512];
    while (fgets(line, sizeof line, f)) {
        unsigned long a, b;
        char perms[8], name[300] = "";
        if (sscanf(line, "%lx-%lx %7s %*s %*s %*s %299[^\n]", &a, &b, perms, name) < 3) continue;
        unsigned long kb = (b - a) / 1024;
        const char *label;
        char *nm = name;
        while (*nm == ' ') nm++;

        if (!strcmp(nm, "[heap]"))                         { label = "HEAP (malloc)";       heap += kb; }
        else if (!strncmp(nm, "[stack", 6))                { label = "STACK";               stack += kb; }
        else if (nm[0] == '[')                             { label = "kernel-provided";     kern += kb; }
        else if (nm[0] == '/' && perms[2] == 'x')          { label = !strcmp(nm, exe) ? "CODE (program)" : "CODE (shared library)"; code += kb; }
        else if (nm[0] == '/')                             { label = "file data/globals";   filedata += kb; }
        else                                               { label = "anonymous mmap/bss";  anon += kb; }

        regions++;
        if (lines < 22) {
            printf("   %012lx-%012lx %-5s %7luKB  %s %s\n", a, b, perms, kb, label,
                   nm[0] ? nm : "");
            lines++;
        }
    }
    fclose(f);
    if (regions > lines) printf("   ... %d more regions not shown\n", regions - lines);

    printf("\n   totals: code %luKB | heap %luKB | stack %luKB | file data %luKB | anonymous %luKB | kernel-provided %luKB\n",
           code, heap, stack, filedata, anon, kern);

    long size = 0, res = 0, shr = 0;
    char who[16];
    snprintf(who, sizeof who, "%d", pid);
    if (read_statm(who, &size, &res, &shr) == 0) {
        section("Virtual vs physical memory (/proc/PID/statm)");
        printf("   virtual size : %ld pages = %ld KB (address space promised)\n", size, size * g_ps / 1024);
        printf("   resident (RSS): %ld pages = %ld KB (actually in RAM)\n", res, res * g_ps / 1024);
        printf("   shared pages : %ld  (library/file pages shared with other processes)\n", shr);
    }

    /* page-fault counters: stat fields 10 (minflt) and 12 (majflt) */
    snprintf(path, sizeof path, "/proc/%d/stat", pid);
    f = fopen(path, "r");
    if (f) {
        char buf[2048];
        size_t r = fread(buf, 1, sizeof buf - 1, f);
        fclose(f);
        buf[r] = '\0';
        char *rp = strrchr(buf, ')');
        unsigned long minf = 0, majf = 0, dummy;
        if (rp && sscanf(rp + 2, "%*c %*d %*d %*d %*d %*d %*u %lu %lu %lu %lu",
                         &minf, &dummy, &majf, &dummy) == 4) {
            section("Page faults so far");
            printf("   minor faults : %lu  (page was in RAM or zero-fill; only the page table changed)\n", minf);
            printf("   major faults : %lu  (page had to be read from disk)\n", majf);
        }
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/*  --mem-demo helpers                                                  */
/* ------------------------------------------------------------------ */
static void show_translation(const char *what, void *addr) {
    int fd = open("/proc/self/pagemap", O_RDONLY);
    uint64_t e = 0;
    uintptr_t va = (uintptr_t)addr;
    printf("   %s: virtual address 0x%lx = page #%lu + offset %lu\n", what,
           (unsigned long)va, (unsigned long)(va / g_ps), (unsigned long)(va % g_ps));
    if (fd < 0 || pread(fd, &e, sizeof e, (off_t)(va / g_ps) * 8) != sizeof e) {
        printf("      (pagemap not readable here)\n");
        if (fd >= 0) close(fd);
        return;
    }
    close(fd);
    int present = (int)((e >> 63) & 1);
    uint64_t pfn = e & ((1ULL << 55) - 1);
    if (!present)
        printf("      page table: NOT present in RAM -> first access raises a page fault\n");
    else if (pfn)
        printf("      page table: present, frame #%lu -> physical address 0x%lx\n",
               (unsigned long)pfn, (unsigned long)(pfn * g_ps + va % g_ps));
    else
        printf("      page table: present in RAM (frame number hidden unless run as root)\n");
}

static void demo_demand_paging(void) {
    section("1+2. Demand paging and virtual -> physical translation");
    size_t npages = 4096, len = npages * (size_t)g_ps;
    long size0, res0, sh;
    read_statm("self", &size0, &res0, &sh);       /* warm-up: first fopen allocates a buffer */
    read_statm("self", &size0, &res0, &sh);
    long f0 = minflt_self();

    char *p = mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) { perror("mmap"); return; }

    long size1, res1;
    read_statm("self", &size1, &res1, &sh);
    printf("   mmap(%zu KB): virtual size grew by %ld KB, resident grew by %ld KB\n",
           len / 1024, (size1 - size0) * g_ps / 1024, (res1 - res0) * g_ps / 1024);
    printf("   -> the kernel only reserved ADDRESS SPACE; no RAM was given yet.\n\n");
    show_translation("first page ", p);

    for (size_t i = 0; i < npages / 2; i++) p[i * g_ps] = 1;   /* touch half the pages */
    long f1 = minflt_self();
    long size2, res2;
    read_statm("self", &size2, &res2, &sh);
    printf("\n   wrote 1 byte into each of the first %zu pages:\n", npages / 2);
    printf("   minor page faults: %ld   (one per page touched - demand paging)\n", f1 - f0);
    printf("   resident memory grew by %ld KB, virtual size unchanged\n", (res2 - res1) * g_ps / 1024);
    printf("   (with transparent huge pages enabled the fault count can be lower)\n\n");
    show_translation("first page ", p);
    show_translation("last page  ", p + (npages - 1) * g_ps);

    printf("\n   Each memory access uses the MMU: virtual page -> (TLB hit? use cached\n"
           "   translation : walk the page table) -> physical frame. On a miss with no\n"
           "   valid entry the CPU raises a page fault and the kernel maps a frame.\n");
    munmap(p, len);
}

static void demo_cow(void) {
    section("3. Copy-on-write: fork() shares memory until somebody writes");
    size_t npages = 2048, len = npages * (size_t)g_ps;
    char *buf = mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (buf == MAP_FAILED) { perror("mmap"); return; }
    memset(buf, 'A', len);                          /* parent owns %zu real pages */

    int fd[2];
    if (pipe(fd) < 0) { perror("pipe"); return; }
    pid_t c = safe_fork();
    if (c == 0) {
        long r[3];
        long f0 = minflt_self();
        volatile unsigned long sum = 0;
        for (size_t i = 0; i < npages; i++) sum += (unsigned char)buf[i * g_ps];
        long f1 = minflt_self();
        for (size_t i = 0; i < npages; i++) buf[i * g_ps] = 'B';
        long f2 = minflt_self();
        r[0] = f1 - f0; r[1] = f2 - f1; r[2] = (long)(buf[0] == 'B');
        write_full(fd[1], r, sizeof r);
        _exit(0);
    }
    close(fd[1]);
    long r[3] = {0};
    read_full(fd[0], r, sizeof r);
    close(fd[0]);
    waitpid(c, NULL, 0);

    printf("   %zu pages (%zu KB) are shared by parent and child right after fork()\n", npages, len / 1024);
    printf("   child READS  all pages -> %ld page faults   (shared, no copy needed)\n", r[0]);
    printf("   child WRITES all pages -> %ld page faults   (each write copies one page)\n", r[1]);
    printf("   parent's data after the child wrote: '%c' (unchanged -> memory is isolated)\n", buf[0]);
    printf("   child saw its own data as: '%s'\n", r[2] ? "B" : "?");
    munmap(buf, len);
}

static void segv_handler(int sig, siginfo_t *si, void *ctx) {
    (void)sig; (void)ctx;
    char b[160];
    int n = snprintf(b, sizeof b, "      kernel delivered SIGSEGV: fault address %p, reason %s\n",
                     si->si_addr,
                     si->si_code == SEGV_MAPERR ? "SEGV_MAPERR (address not mapped at all)" :
                     si->si_code == SEGV_ACCERR ? "SEGV_ACCERR (mapped, but permission denied)" : "other");
    IGNORE_RESULT(write(STDOUT_FILENO, b, (size_t)n));
    /* SA_RESETHAND restored the default action: returning re-runs the bad
     * instruction, so the kernel now terminates the process. */
}

static void run_fault(int kind) {
    pid_t c = safe_fork();
    if (c == 0) {
        struct sigaction sa;
        memset(&sa, 0, sizeof sa);
        sa.sa_sigaction = segv_handler;
        sa.sa_flags = SA_SIGINFO | SA_RESETHAND;
        sigaction(SIGSEGV, &sa, NULL);
        if (kind == 0) {
            *(volatile int *)0 = 1;                                  /* NULL write */
        } else {
            char *ro = mmap(NULL, (size_t)g_ps, PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
            ro[0] = 1;                                               /* write to read-only page */
        }
        _exit(0);
    }
    int st = 0;
    waitpid(c, &st, 0);
    if (WIFSIGNALED(st))
        printf("      result: child killed by signal %d (%s) - the OS protected everyone else\n",
               WTERMSIG(st), strsignal(WTERMSIG(st)));
}

static void demo_errors(void) {
    section("4. Memory errors and how the OS responds");
    printf("   a) write through a NULL pointer\n");
    run_fault(0);
    printf("   b) write into a read-only page (PROT_READ)\n");
    run_fault(1);
}

int co4_demo(void) {
    banner("CO4", "Virtual memory experiments on this very process");
    g_ps = sysconf(_SC_PAGESIZE);
    printf("   page size = %ld bytes\n", g_ps);
    demo_demand_paging();
    demo_cow();
    demo_errors();
    printf("\n   Memory debugging tools: valgrind ./ptree -o   |   gcc -fsanitize=address\n"
           "   Watch faults live:      /usr/bin/time -v ./ptree -o\n");
    return 0;
}
