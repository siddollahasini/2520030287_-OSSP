/*
 * co6_threads.c - CO6: concurrency and synchronisation (POSIX threads)
 *
 *   --race-demo      shared counter: no lock (race) vs mutex vs atomic
 *   --threads        parallel /proc scan using a bounded buffer:
 *                      mutex + 2 condition variables (producer/consumer)
 *                      counting semaphore (limit concurrent /proc readers)
 *   --deadlock-demo  two threads, opposite lock order -> deadlock (detected
 *                    with a timeout), then fixed with a global lock order
 */
#include "ptree.h"

#include <dirent.h>
#include <errno.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static double now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1e3 + ts.tv_nsec / 1e6;
}

/* ================================================================== */
/* 1. race condition                                                   */
/* ================================================================== */
#define RACE_THREADS 4
#define RACE_ITERS   1000000

static volatile long g_unsafe;
static long g_locked;
static atomic_long g_atomic;
static pthread_mutex_t g_mtx = PTHREAD_MUTEX_INITIALIZER;

static void *w_unsafe(void *a) { (void)a; for (int i = 0; i < RACE_ITERS; i++) g_unsafe = g_unsafe + 1; return NULL; }
static void *w_mutex(void *a)  { (void)a; for (int i = 0; i < RACE_ITERS; i++) { pthread_mutex_lock(&g_mtx); g_locked++; pthread_mutex_unlock(&g_mtx); } return NULL; }
static void *w_atomic(void *a) { (void)a; for (int i = 0; i < RACE_ITERS; i++) atomic_fetch_add(&g_atomic, 1); return NULL; }

static double run_threads(void *(*fn)(void *)) {
    pthread_t t[RACE_THREADS];
    double t0 = now_ms();
    for (int i = 0; i < RACE_THREADS; i++) pthread_create(&t[i], NULL, fn, NULL);
    for (int i = 0; i < RACE_THREADS; i++) pthread_join(t[i], NULL);
    return now_ms() - t0;
}

int co6_race(void) {
    banner("CO6", "Race condition on shared data");
    long expected = (long)RACE_THREADS * RACE_ITERS;
    printf("   %d threads each add 1 to a shared counter %d times; expected total = %ld\n",
           RACE_THREADS, RACE_ITERS, expected);
    printf("   CPUs online: %ld\n\n", sysconf(_SC_NPROCESSORS_ONLN));

    double a = run_threads(w_unsafe);
    printf("   no lock      : counter = %-8ld lost updates = %-8ld (%.0f ms)  <-- RACE\n",
           (long)g_unsafe, expected - g_unsafe, a);
    double b = run_threads(w_mutex);
    printf("   mutex        : counter = %-8ld lost updates = %-8ld (%.0f ms)\n", g_locked, expected - g_locked, b);
    double c = run_threads(w_atomic);
    printf("   atomic add   : counter = %-8ld lost updates = %-8ld (%.0f ms)\n",
           (long)atomic_load(&g_atomic), expected - (long)atomic_load(&g_atomic), c);

    printf("\n   counter++ is three steps (load, add, store). Two threads can load the same\n"
           "   value and both store value+1, so one increment is lost. A mutex makes the\n"
           "   critical section mutually exclusive. (On a single CPU the race can be rare.)\n");
    return 0;
}

/* ================================================================== */
/* 2. parallel /proc scan: bounded buffer + semaphore                  */
/* ================================================================== */
#define QCAP     8
#define NWORKERS 4

typedef struct { int pid; int idx; } Job;

static struct {
    Job             q[QCAP];
    int             head, tail, count, done;
    pthread_mutex_t lock;
    pthread_cond_t  not_full, not_empty;
    long            producer_waits;
    sem_t           io_slots;                       /* counting semaphore */
    Proc           *results;
    char           *ok;
    long            handled[NWORKERS];
    int             max_concurrent_io, cur_io;
} g;

static void *scan_worker(void *arg) {
    long id = (long)arg;
    for (;;) {
        pthread_mutex_lock(&g.lock);
        while (g.count == 0 && !g.done)
            pthread_cond_wait(&g.not_empty, &g.lock);   /* sleep until work arrives */
        if (g.count == 0 && g.done) { pthread_mutex_unlock(&g.lock); break; }
        Job j = g.q[g.head];
        g.head = (g.head + 1) % QCAP;
        g.count--;
        pthread_cond_signal(&g.not_full);               /* a slot is free again */
        pthread_mutex_unlock(&g.lock);

        sem_wait(&g.io_slots);                          /* at most 2 readers at once */
        pthread_mutex_lock(&g.lock);
        if (++g.cur_io > g.max_concurrent_io) g.max_concurrent_io = g.cur_io;
        pthread_mutex_unlock(&g.lock);

        g.ok[j.idx] = (read_process(j.pid, &g.results[j.idx]) == 0);
        usleep(200);                                    /* pretend the read is slow */

        pthread_mutex_lock(&g.lock);
        g.cur_io--;
        pthread_mutex_unlock(&g.lock);
        sem_post(&g.io_slots);

        g.handled[id]++;                                /* private to this worker */
    }
    return NULL;
}

int co6_threads(void) {
    banner("CO6", "Producer/consumer with mutex, condition variables and a semaphore");

    /* list PIDs */
    int cap = 1024, npids = 0;
    int *pids = malloc(sizeof(int) * (size_t)cap);
    DIR *d = opendir("/proc");
    struct dirent *e;
    while (d && (e = readdir(d)) != NULL) {
        int pid = atoi(e->d_name);
        if (pid <= 0) continue;
        if (npids == cap) { cap *= 2; pids = realloc(pids, sizeof(int) * (size_t)cap); }
        pids[npids++] = pid;
    }
    if (d) closedir(d);

    /* baseline: sequential scan */
    Snapshot seq = {0};
    double t0 = now_ms();
    snapshot_load(&seq);
    double t_seq = now_ms() - t0;

    memset(&g, 0, sizeof g);
    pthread_mutex_init(&g.lock, NULL);
    pthread_cond_init(&g.not_full, NULL);
    pthread_cond_init(&g.not_empty, NULL);
    sem_init(&g.io_slots, 0, 2);
    g.results = calloc((size_t)npids, sizeof(Proc));
    g.ok = calloc((size_t)npids, 1);

    pthread_t th[NWORKERS];
    t0 = now_ms();
    for (long i = 0; i < NWORKERS; i++) pthread_create(&th[i], NULL, scan_worker, (void *)i);

    /* our own threads are visible in /proc/self/task */
    int nthreads = 0;
    DIR *td = opendir("/proc/self/task");
    while (td && (e = readdir(td)) != NULL) if (e->d_name[0] != '.') nthreads++;
    if (td) closedir(td);
    printf("   ptree now has %d threads (1 main + %d workers) - see /proc/%d/task\n", nthreads, NWORKERS, getpid());

    /* producer = main thread: blocks when the bounded buffer is full */
    for (int i = 0; i < npids; i++) {
        pthread_mutex_lock(&g.lock);
        while (g.count == QCAP) { g.producer_waits++; pthread_cond_wait(&g.not_full, &g.lock); }
        g.q[g.tail] = (Job){ pids[i], i };
        g.tail = (g.tail + 1) % QCAP;
        g.count++;
        pthread_cond_signal(&g.not_empty);
        pthread_mutex_unlock(&g.lock);
    }
    pthread_mutex_lock(&g.lock);
    g.done = 1;
    pthread_cond_broadcast(&g.not_empty);               /* wake every sleeping worker */
    pthread_mutex_unlock(&g.lock);
    for (int i = 0; i < NWORKERS; i++) pthread_join(th[i], NULL);
    double t_par = now_ms() - t0;

    int good = 0;
    for (int i = 0; i < npids; i++) good += g.ok[i];

    printf("   PIDs found in /proc : %d\n", npids);
    printf("   buffer size         : %d jobs (producer had to wait %ld times because it was full)\n", QCAP, g.producer_waits);
    printf("   semaphore           : max 2 concurrent /proc readers, observed peak = %d\n", g.max_concurrent_io);
    for (int i = 0; i < NWORKERS; i++) printf("   worker %d processed  : %ld PIDs\n", i, g.handled[i]);
    printf("   results             : %d processes read in parallel, %d in the sequential scan\n", good, seq.count);
    printf("   time                : sequential %.2f ms, parallel %.2f ms (workers deliberately slowed;\n"
           "                         the point is correct coordination, not speed)\n", t_seq, t_par);
    printf("\n   mutex protects the queue indexes | not_full / not_empty condition variables make\n"
           "   threads sleep instead of busy-waiting | the semaphore counts free I/O slots.\n");

    snapshot_free(&seq);
    free(g.results); free(g.ok); free(pids);
    sem_destroy(&g.io_slots);
    return 0;
}

/* ================================================================== */
/* 3. deadlock                                                         */
/* ================================================================== */
static pthread_mutex_t g_A = PTHREAD_MUTEX_INITIALIZER, g_B = PTHREAD_MUTEX_INITIALIZER;
static pthread_barrier_t g_bar;

typedef struct { pthread_mutex_t *first, *second; const char *name; int use_barrier; int err; } LockArgs;

static void *locker(void *p) {
    LockArgs *a = p;
    pthread_mutex_lock(a->first);
    usleep(150000);                                     /* give the other thread time to grab its lock */
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    ts.tv_sec += 1;
    a->err = pthread_mutex_timedlock(a->second, &ts);
    if (a->err == 0) pthread_mutex_unlock(a->second);
    if (a->use_barrier) pthread_barrier_wait(&g_bar);   /* keep holding 'first' until both gave up */
    pthread_mutex_unlock(a->first);
    return NULL;
}

int co6_deadlock(void) {
    banner("CO6", "Deadlock: circular wait, detection and prevention");

    printf("\n   Run 1: thread T1 locks A then B, thread T2 locks B then A (opposite order)\n");
    pthread_barrier_init(&g_bar, NULL, 2);
    LockArgs x = { &g_A, &g_B, "T1", 1, 0 }, y = { &g_B, &g_A, "T2", 1, 0 };
    pthread_t t1, t2;
    double t0 = now_ms();
    pthread_create(&t1, NULL, locker, &x);
    pthread_create(&t2, NULL, locker, &y);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_barrier_destroy(&g_bar);
    printf("   T1 waiting for B: %s\n", x.err == 0 ? "got it" : "TIMED OUT");
    printf("   T2 waiting for A: %s\n", y.err == 0 ? "got it" : "TIMED OUT");
    if (x.err && y.err)
        printf("   -> DEADLOCK after %.0f ms: T1 holds A and wants B, T2 holds B and wants A.\n"
               "      (A plain pthread_mutex_lock would have hung forever; timedlock let us detect it.)\n",
               now_ms() - t0);

    printf("\n   Run 2: both threads lock in the SAME global order (A before B)\n");
    LockArgs p = { &g_A, &g_B, "T1", 0, 0 }, q = { &g_A, &g_B, "T2", 0, 0 };
    t0 = now_ms();
    pthread_create(&t1, NULL, locker, &p);
    pthread_create(&t2, NULL, locker, &q);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    printf("   T1: %s, T2: %s  (%.0f ms) -> no circular wait, no deadlock\n",
           p.err == 0 ? "OK" : "FAILED", q.err == 0 ? "OK" : "FAILED", now_ms() - t0);

    printf("\n   Four conditions for deadlock: mutual exclusion, hold-and-wait, no preemption,\n"
           "   circular wait. Breaking any one prevents it - here we broke circular wait.\n"
           "   Starvation is different: a thread is never deadlocked but never gets the lock\n"
           "   (e.g. unfair priority or readers always beating a writer); fair queues fix it.\n");
    return 0;
}
