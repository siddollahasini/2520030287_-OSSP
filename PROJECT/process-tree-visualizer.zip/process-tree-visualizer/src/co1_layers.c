/*
 * co1_layers.c - CO1: the operating system as a layered service abstraction
 *
 * Shows, with real measurements from the running system:
 *   - one OS service reached through three layers (libc, raw syscall, VFS)
 *   - kernel information obtained through a system call
 *   - the cost of a user -> kernel mode switch
 *   - the shell as an ordinary user-space program (our ancestors)
 *   - hardware-enforced protection: user code cannot touch kernel memory
 *   - the journey of a command from the shell to the kernel and back
 */
#include "ptree.h"

#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static double now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1e9 + ts.tv_nsec;
}

/* A plain function call stays in user mode (no privilege change). */
__attribute__((noinline)) static long user_call(long x) {
    __asm__ volatile("" : "+r"(x));
    return x + 1;
}

static int pid_from_proc_self_stat(void) {
    /* Same service, third route: ask the kernel's VFS using open/read/close. */
    char buf[256];
    int fd = open("/proc/self/stat", O_RDONLY);
    if (fd < 0) return -1;
    ssize_t n = read(fd, buf, sizeof buf - 1);
    close(fd);
    if (n <= 0) return -1;
    buf[n] = '\0';
    return atoi(buf);                       /* first field of stat = PID */
}

int co1_layers(void) {
    banner("CO1", "Operating system as a layered service abstraction");

    printf(
"\n  +-----------------------------------------+\n"
"  | Application   : ptree (this program)    |  USER MODE   (ring 3)\n"
"  | C library     : glibc wrappers (getpid) |  USER MODE\n"
"  +=========== SYSTEM CALL INTERFACE =======+  <-- 'syscall' instruction\n"
"  | Kernel        : VFS, scheduler, memory  |  KERNEL MODE (ring 0)\n"
"  | Device drivers                          |\n"
"  +-----------------------------------------+\n"
"  | Hardware      : CPU, RAM, disk          |\n"
"  +-----------------------------------------+\n");

    /* ---- 1: one service, three routes ---- */
    section("1. One OS service (\"what is my PID?\") reached three ways");
    long a = getpid();                          /* libc wrapper -> syscall */
    long b = syscall(SYS_getpid);               /* raw system call         */
    long c = pid_from_proc_self_stat();         /* open+read+close via VFS */
    printf("   libc  getpid()              = %ld\n", a);
    printf("   raw   syscall(SYS_getpid)   = %ld   (syscall number %d)\n", b, SYS_getpid);
    printf("   VFS   read(/proc/self/stat) = %ld   (3 syscalls: open, read, close)\n", c);
    printf("   -> %s: all routes end in the kernel, only the abstraction level differs.\n",
           (a == b && b == c) ? "same answer" : "MISMATCH");

    /* ---- 2: kernel info via syscall ---- */
    section("2. Asking the kernel about itself (uname system call)");
    struct utsname u;
    if (uname(&u) == 0)
        printf("   kernel: %s %s on %s, host: %s\n", u.sysname, u.release, u.machine, u.nodename);

    /* ---- 3: cost of mode switch ---- */
    section("3. User-mode function call vs system call (mode switch cost)");
    const long N = 2000000;
    volatile long sink = 0;
    double t0 = now_ns();
    for (long i = 0; i < N; i++) sink += user_call(i);
    double t1 = now_ns();
    for (long i = 0; i < N; i++) sink += syscall(SYS_getppid);
    double t2 = now_ns();
    (void)sink;
    printf("   normal function call : %7.1f ns each (stays in user mode)\n", (t1 - t0) / N);
    printf("   system call          : %7.1f ns each (user -> kernel -> user)\n", (t2 - t1) / N);
    printf("   -> crossing into the kernel costs about %.0fx more.\n",
           (t2 - t1) / (t1 - t0 > 0 ? (t1 - t0) : 1));

    /* ---- 4: shell is just a user program ---- */
    section("4. The shell is an ordinary user-space program (our ancestors)");
    int chain[64], n = 0;
    for (int pid = getpid(); pid > 0 && n < 64; ) {
        Proc p;
        if (read_process(pid, &p) != 0) break;
        chain[n++] = pid;
        if (p.ppid == pid || p.ppid <= 0) break;
        pid = p.ppid;
    }
    printf("   ");
    for (int i = 0; i < n; i++) {
        Proc p;
        if (read_process(chain[i], &p) == 0) printf("%s(%d)%s", p.comm, p.pid, i + 1 < n ? " -> " : "\n");
    }
    printf("   (read left to right: child -> parent -> ... -> root). The shell only\n"
           "    parses text and calls fork/execve/wait; the kernel does the real work.\n");

    /* ---- 5: protection ---- */
#if defined(__x86_64__) || defined(__aarch64__)
    section("5. Hardware-enforced protection: user code reading kernel memory");
    pid_t child = safe_fork();
    if (child == 0) {
        volatile char *kernel_addr = (volatile char *)0xffff800000000000UL;
        char x = *kernel_addr;              /* illegal in user mode */
        (void)x;
        _exit(0);
    }
    int st = 0;
    waitpid(child, &st, 0);
    if (WIFSIGNALED(st))
        printf("   child tried to read a kernel address -> killed by signal %d (%s)\n"
               "   -> the CPU blocked the access and the kernel enforced the rule.\n",
               WTERMSIG(st), strsignal(WTERMSIG(st)));
#endif

    /* ---- 6: command journey ---- */
    section("6. Journey of a command:  $ ./ptree -o");
    printf(
"   1. Shell (user space) reads the line and splits it into words.\n"
"   2. Shell calls fork()            -> kernel creates a child process.\n"
"   3. Child calls execve(\"./ptree\") -> kernel loads the program image.\n"
"   4. ptree runs: open/read on /proc, write() to the terminal (syscalls).\n"
"   5. ptree calls exit_group()      -> kernel frees its resources.\n"
"   6. Shell's wait4() returns; the shell prints the next prompt.\n"
"   Try it yourself:   strace -f -e trace=execve,openat,write ./ptree -o\n"
"   Summary of all syscalls:  strace -c ./ptree -o\n");
    return 0;
}
