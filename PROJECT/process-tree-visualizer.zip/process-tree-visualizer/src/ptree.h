/*
 * ptree.h - shared declarations for the Linux Process Tree Visualizer
 *
 * Module map (one module per course outcome of the OS handout):
 *   proc.c        core   : reads /proc, builds the parent-child tree
 *   viewer.c      core   : draws the tree in the terminal
 *   co1_layers.c  CO1    : OS as a layered service (user/kernel, syscalls, shell)
 *   co2_process.c CO2    : fork / exec / wait / exit
 *   co3_ipc.c     CO3    : pipes, FIFOs, signals, shared memory, UNIX sockets
 *   co4_memory.c  CO4    : virtual memory, paging, page faults, copy-on-write
 *   co5_files.c   CO5    : inodes, VFS, file descriptors, file I/O syscalls
 *   co6_threads.c CO6    : POSIX threads, mutex, condvar, semaphore, deadlock
 */
#ifndef PTREE_H
#define PTREE_H

#include <stddef.h>
#include <sys/types.h>

/* Explicitly ignore a return value (silences warn_unused_result). */
#define IGNORE_RESULT(x) do { long ignored_ = (long)(x); (void)ignored_; } while (0)

/* ---------------- core data structures ---------------- */
typedef struct {
    int   pid;
    int   ppid;
    char  comm[64];      /* process name                          */
    char  state;         /* R, S, D, Z, T, I ...                  */
    uid_t uid;           /* owner                                 */
    long  rss_kb;        /* resident memory in KB                 */
    long  threads;       /* number of threads                     */
    int   is_new;        /* appeared since previous snapshot      */
    int   first_child;   /* index of first child, -1 if none      */
    int   next_sibling;  /* index of next sibling, -1 if none     */
    int   is_kthread;    /* kernel thread (child of kthreadd)     */
} Proc;

typedef struct {
    Proc *items;
    int   count;
    int   cap;
} Snapshot;

typedef struct {
    int  total, running, sleeping, stopped, zombie;
    long threads;
} Stats;

typedef struct {
    int interval;        /* seconds between refreshes             */
    int once;            /* print once and exit                   */
    int root_pid;        /* 0 = show full tree                    */
    int max_depth;       /* 0 = unlimited                         */
    int hide_kthreads;   /* hide kernel threads                   */
    int no_color;
} Options;

extern Options g_opt;
extern int     g_color;

/* ---------------- proc.c ---------------- */
int  read_process(int pid, Proc *p);          /* 0 ok, -1 process vanished */
int  snapshot_load(Snapshot *s);
void snapshot_free(Snapshot *s);
int  find_pid(const Snapshot *s, int pid);    /* snapshot sorted by pid    */
void build_tree(Snapshot *s, int *roots, int *nroots);
void snapshot_stats(const Snapshot *s, Stats *st);

/* ---------------- viewer.c ---------------- */
void viewer_render(Snapshot *cur, const Snapshot *prev, int have_prev, int rows);
void viewer_print_subtree(int pid, int color);   /* loads a fresh snapshot  */
void banner(const char *co, const char *title);
void section(const char *text);

/* ---------------- helpers shared by modules (co5_files.c) ---------------- */
ssize_t write_full(int fd, const void *buf, size_t n);  /* retries EINTR/partial */
ssize_t read_full(int fd, void *buf, size_t n);         /* reads until n or EOF  */
pid_t   safe_fork(void);                                /* flushes stdio first   */

/* ---------------- course-outcome modules ---------------- */
int co1_layers(void);
int co2_spawn(int argc, char **argv);
int co2_zombie(void);
int co2_orphan(void);
int co3_ipc(void);
int co4_inspect(int pid);
int co4_demo(void);
int co5_files(int pid);
int co5_fs_demo(void);
int co5_save(const char *path);
int co5_load(const char *path);
int co6_race(void);
int co6_threads(void);
int co6_deadlock(void);

#endif
