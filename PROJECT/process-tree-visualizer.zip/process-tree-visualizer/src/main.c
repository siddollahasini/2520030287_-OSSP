/*
 * Linux Process Tree Visualizer
 * -----------------------------
 * Displays the hierarchy of running processes and their parent-child
 * relationships in real time, directly in the terminal.
 *
 * main.c : command line + the live refresh loop.
 * Each course outcome (CO1..CO6) has its own module - see ptree.h.
 */
#include "ptree.h"

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

static volatile sig_atomic_t g_running = 1;
static volatile sig_atomic_t g_refresh_now = 0;   /* SIGUSR1 */
static volatile sig_atomic_t g_toggle_k = 0;      /* SIGUSR2 */

static void on_term(int sig) { (void)sig; g_running = 0; }
static void on_usr1(int sig) { (void)sig; g_refresh_now = 1; }
static void on_usr2(int sig) { (void)sig; g_toggle_k = 1; }

typedef enum {
    M_LIVE, M_LAYERS, M_SPAWN, M_ZOMBIE, M_ORPHAN, M_IPC, M_MEM, M_MEMDEMO,
    M_FILES, M_FSDEMO, M_SAVE, M_LOAD, M_THREADS, M_RACE, M_DEADLOCK, M_ALL
} Mode;

static void usage(const char *prog) {
    printf(
"Linux Process Tree Visualizer\n\n"
"Usage: %s [options]\n\n"
"VIEWER OPTIONS\n"
"  -i SEC          refresh interval in seconds (default 1)\n"
"  -o              print the tree once and exit (no live refresh)\n"
"  -p PID          show only the subtree starting at PID\n"
"  -d N            limit tree depth to N levels\n"
"  -k              hide kernel threads\n"
"  -n              disable colours\n"
"  -h              this help\n\n"
"COURSE-OUTCOME DEMOS\n"
"  CO1  --layers              user/kernel space, system calls, role of the shell\n"
"  CO2  --spawn CMD [ARGS]    fork + exec + wait a command, watch it in the tree\n"
"       --zombie              create and reap a zombie process\n"
"       --orphan              orphan process gets a new parent (re-parenting)\n"
"  CO3  --ipc                 pipe, FIFO, signals, process groups, shared memory,\n"
"                             UNIX domain socket\n"
"  CO4  --mem [PID]           address-space layout + page faults of a process\n"
"       --mem-demo            demand paging, virtual->physical, copy-on-write, SIGSEGV\n"
"  CO5  --files [PID]         open file descriptors -> inodes (VFS view)\n"
"       --fs-demo             inodes, links, lseek, buffered I/O, mmap, mount info\n"
"       --save FILE           save a snapshot as a binary file\n"
"       --load FILE           replay a saved snapshot as a tree\n"
"  CO6  --threads             parallel /proc scan: mutex + condvar + semaphore\n"
"       --race-demo           race condition vs mutex vs atomic\n"
"       --deadlock-demo       deadlock detection and lock ordering\n"
"  ALL  --demo-all            run every demo above in order\n\n"
"LIVE-MODE SIGNALS\n"
"  kill -USR1 <ptree pid>     refresh immediately\n"
"  kill -USR2 <ptree pid>     toggle hiding of kernel threads\n"
"  Ctrl+C                     quit\n\n"
"LEGEND  + = new process, [R] running, [S] sleeping, [D] disk wait,\n"
"        [Z] zombie, [T] stopped\n", prog);
}

static int is_all_digits(const char *s) {
    if (!*s) return 0;
    for (; *s; s++) if (*s < '0' || *s > '9') return 0;
    return 1;
}

static int run_all(const char *prog) {
    (void)prog;
    char *echo_cmd[] = { "sleep", "1", NULL };
    co1_layers();
    co2_spawn(2, echo_cmd);
    co2_zombie();
    co2_orphan();
    co3_ipc();
    co4_inspect(0);
    co4_demo();
    co5_files(0);
    co5_fs_demo();
    co6_race();
    co6_threads();
    co6_deadlock();
    return 0;
}

int main(int argc, char **argv) {
    Mode mode = M_LIVE;
    int extra_pid = 0;
    const char *extra_path = NULL;
    int spawn_argc = 0;
    char **spawn_argv = NULL;

    g_opt.interval = 1;
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { usage(argv[0]); return 0; }
        else if (!strcmp(a, "-o")) g_opt.once = 1;
        else if (!strcmp(a, "-k")) g_opt.hide_kthreads = 1;
        else if (!strcmp(a, "-n")) g_opt.no_color = 1;
        else if (!strcmp(a, "-i") && i + 1 < argc) g_opt.interval = atoi(argv[++i]);
        else if (!strcmp(a, "-p") && i + 1 < argc) g_opt.root_pid = atoi(argv[++i]);
        else if (!strcmp(a, "-d") && i + 1 < argc) g_opt.max_depth = atoi(argv[++i]);
        else if (!strcmp(a, "--layers"))        mode = M_LAYERS;
        else if (!strcmp(a, "--zombie"))        mode = M_ZOMBIE;
        else if (!strcmp(a, "--orphan"))        mode = M_ORPHAN;
        else if (!strcmp(a, "--ipc"))           mode = M_IPC;
        else if (!strcmp(a, "--mem-demo"))      mode = M_MEMDEMO;
        else if (!strcmp(a, "--fs-demo"))       mode = M_FSDEMO;
        else if (!strcmp(a, "--threads"))       mode = M_THREADS;
        else if (!strcmp(a, "--race-demo"))     mode = M_RACE;
        else if (!strcmp(a, "--deadlock-demo")) mode = M_DEADLOCK;
        else if (!strcmp(a, "--demo-all"))      mode = M_ALL;
        else if (!strcmp(a, "--mem") || !strcmp(a, "--files")) {
            mode = !strcmp(a, "--mem") ? M_MEM : M_FILES;
            if (i + 1 < argc && is_all_digits(argv[i + 1])) extra_pid = atoi(argv[++i]);
        }
        else if (!strcmp(a, "--save") && i + 1 < argc) { mode = M_SAVE; extra_path = argv[++i]; }
        else if (!strcmp(a, "--load") && i + 1 < argc) { mode = M_LOAD; extra_path = argv[++i]; }
        else if (!strcmp(a, "--spawn") && i + 1 < argc) {
            mode = M_SPAWN;
            spawn_argc = argc - (i + 1);
            spawn_argv = &argv[i + 1];
            break;                       /* everything after --spawn is the command */
        }
        else {
            fprintf(stderr, "Unknown or incomplete option: %s\n\n", a);
            usage(argv[0]);
            return 1;
        }
    }
    if (g_opt.interval < 1) g_opt.interval = 1;
    g_color = !g_opt.no_color && isatty(STDOUT_FILENO);

    switch (mode) {
        case M_LAYERS:   return co1_layers();
        case M_SPAWN:    return co2_spawn(spawn_argc, spawn_argv);
        case M_ZOMBIE:   return co2_zombie();
        case M_ORPHAN:   return co2_orphan();
        case M_IPC:      return co3_ipc();
        case M_MEM:      return co4_inspect(extra_pid);
        case M_MEMDEMO:  return co4_demo();
        case M_FILES:    return co5_files(extra_pid);
        case M_FSDEMO:   return co5_fs_demo();
        case M_SAVE:     return co5_save(extra_path);
        case M_LOAD:     return co5_load(extra_path);
        case M_THREADS:  return co6_threads();
        case M_RACE:     return co6_race();
        case M_DEADLOCK: return co6_deadlock();
        case M_ALL:      return run_all(argv[0]);
        case M_LIVE:     break;
    }

    /* ------------------- viewer: one-shot or live ------------------- */
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_term;
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    sa.sa_handler = on_usr1;
    sigaction(SIGUSR1, &sa, NULL);
    sa.sa_handler = on_usr2;
    sigaction(SIGUSR2, &sa, NULL);

    Snapshot prev = {0}, cur = {0};
    int have_prev = 0;
    int tty = isatty(STDOUT_FILENO);

    if (!g_opt.once && tty) printf("\033[?25l");               /* hide cursor */

    while (g_running) {
        if (g_toggle_k) { g_opt.hide_kthreads = !g_opt.hide_kthreads; g_toggle_k = 0; }
        g_refresh_now = 0;
        if (snapshot_load(&cur) != 0) break;

        struct winsize ws;
        int rows = 40;
        if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_row > 0) rows = ws.ws_row;

        if (!g_opt.once && tty) printf("\033[H\033[2J");        /* clear */
        viewer_render(&cur, &prev, have_prev, rows);

        if (g_opt.once) { snapshot_free(&cur); break; }

        printf("\nRefresh: %ds | kernel threads: %s | Ctrl+C to quit\n",
               g_opt.interval, g_opt.hide_kthreads ? "hidden" : "shown");
        fflush(stdout);

        snapshot_free(&prev);
        prev = cur;
        memset(&cur, 0, sizeof cur);
        have_prev = 1;

        for (int t = 0; t < g_opt.interval * 10 && g_running && !g_refresh_now && !g_toggle_k; t++)
            usleep(100000);
    }

    if (!g_opt.once && tty) printf("\033[?25h\n");              /* show cursor */
    snapshot_free(&prev);
    snapshot_free(&cur);
    return 0;
}
