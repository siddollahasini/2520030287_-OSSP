/*
 * co2_process.c - CO2: Unix process control with fork / exec / wait / exit
 *
 *   --spawn CMD   fork a child, exec CMD in it, wait for it, report status
 *   --zombie      child exits but the parent has not wait()ed -> state Z
 *   --orphan      parent of a process dies -> it is re-parented
 */
#include "ptree.h"

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static void report_status(int st) {
    if (WIFEXITED(st))
        printf("   child ended normally, exit status = %d\n", WEXITSTATUS(st));
    else if (WIFSIGNALED(st))
        printf("   child was killed by signal %d (%s)\n", WTERMSIG(st), strsignal(WTERMSIG(st)));
    else
        printf("   child status = 0x%x\n", st);
}

/* ------------------------------------------------------------------ */
int co2_spawn(int argc, char **argv) {
    banner("CO2", "fork + exec + wait: running a command as a child");
    if (argc < 1 || !argv || !argv[0]) {
        fprintf(stderr, "usage: ptree --spawn CMD [ARGS...]\n");
        return 1;
    }

    int gate[2], err[2];
    if (pipe(gate) < 0 || pipe2(err, O_CLOEXEC) < 0) { perror("pipe"); return 1; }

    printf("   parent PID = %d, about to fork() and exec \"%s\"\n", getpid(), argv[0]);
    pid_t pid = safe_fork();                       /* 1. create the child */
    if (pid < 0) { perror("fork"); return 1; }

    if (pid == 0) {                                /* ---- child ---- */
        close(gate[1]);
        close(err[0]);
        char c;
        while (read(gate[0], &c, 1) < 0 && errno == EINTR) { }   /* wait for parent's "go" */
        close(gate[0]);
        execvp(argv[0], argv);                     /* 2. replace the program image */
        int e = errno;                             /* only reached if exec FAILED */
        write_full(err[1], &e, sizeof e);
        _exit(127);
    }

    /* ---- parent ---- */
    close(gate[0]);
    close(err[1]);                                 /* keep only the read end */
    printf("   fork() returned child PID %d in the parent (0 in the child)\n", pid);

    section("Right after fork: the child is a copy of ptree, same program");
    viewer_print_subtree(getpid(), g_color);

    write_full(gate[1], "g", 1);                   /* let the child run exec */
    close(gate[1]);

    /* The err pipe is close-on-exec: EOF means exec succeeded, data means failure. */
    int e = 0;
    ssize_t n = read_full(err[0], &e, sizeof e);
    close(err[0]);
    if (n == (ssize_t)sizeof e) {
        printf("   exec failed in the child: %s\n", strerror(e));
        waitpid(pid, NULL, 0);
        return 1;
    }

    usleep(60000);
    section("After exec: SAME pid, NEW program image");
    viewer_print_subtree(getpid(), g_color);

    int st = 0;
    struct timespec w0, w1;
    clock_gettime(CLOCK_MONOTONIC, &w0);
    waitpid(pid, &st, 0);                          /* 3. parent reaps the child */
    clock_gettime(CLOCK_MONOTONIC, &w1);
    printf("\n   wait() blocked for %ld ms until the child finished - child reaped (no zombie left)\n",
           (long)((w1.tv_sec - w0.tv_sec) * 1000 + (w1.tv_nsec - w0.tv_nsec) / 1000000));
    report_status(st);
    return WIFEXITED(st) ? WEXITSTATUS(st) : 1;
}

/* ------------------------------------------------------------------ */
int co2_zombie(void) {
    banner("CO2", "Zombie process: exited but not yet reaped");

    pid_t pid = safe_fork();
    if (pid == 0) _exit(42);                       /* child ends immediately */

    usleep(200000);                                /* ... parent does NOT wait */
    Proc p;
    section("Child has exited, parent has not called wait() yet");
    if (read_process(pid, &p) == 0)
        printf("   /proc/%d/stat says state = '%c'  (%s)\n", pid, p.state,
               p.state == 'Z' ? "Z = zombie: only the process-table entry remains" : "?");
    viewer_print_subtree(getpid(), g_color);

    int st = 0;
    waitpid(pid, &st, 0);                          /* reaping removes the entry */
    section("After waitpid(): the parent has collected the exit status");
    report_status(st);
    printf("   /proc/%d %s\n", pid, read_process(pid, &p) == 0 ? "still exists" : "is gone - zombie removed");
    printf("   Pitfall: a parent that never waits leaks zombies (process-table slots).\n");
    return 0;
}

/* ------------------------------------------------------------------ */
int co2_orphan(void) {
    banner("CO2", "Orphan process: re-parenting when the parent exits");

    /* Become a "subreaper": orphaned descendants get re-parented to US
     * instead of PID 1 - so the demo works the same everywhere. */
    prctl(PR_SET_CHILD_SUBREAPER, 1);

    int up[2], down[2];
    if (pipe(up) < 0 || pipe(down) < 0) { perror("pipe"); return 1; }

    pid_t a = safe_fork();
    if (a == 0) {                                  /* ---- A: the middle process ---- */
        close(up[0]);
        close(down[1]);
        pid_t b = fork();
        if (b == 0) {                              /* ---- B: the grandchild ---- */
            close(up[1]);
            close(down[0]);
            usleep(1200000);
            _exit(0);
        }
        write_full(up[1], &b, sizeof b);           /* tell main who B is */
        char c;
        IGNORE_RESULT(read(down[0], &c, 1));                      /* wait until main says "exit" */
        _exit(0);                                  /* A dies; B becomes an orphan */
    }
    close(up[1]);
    close(down[0]);

    pid_t b = 0;
    read_full(up[0], &b, sizeof b);
    Proc p;

    section("Before: A (our child) is alive and is the parent of B");
    if (read_process(b, &p) == 0) printf("   B = PID %d, its parent (PPID) = %d  (A = %d)\n", b, p.ppid, a);
    viewer_print_subtree(getpid(), g_color);

    write_full(down[1], "x", 1);                   /* let A exit */
    waitpid(a, NULL, 0);                           /* reap A */
    usleep(100000);

    section("After: A exited, B is an orphan and was re-parented");
    if (read_process(b, &p) == 0)
        printf("   B = PID %d, its parent (PPID) is now %d%s\n", b, p.ppid,
               p.ppid == getpid() ? "  = ptree (the subreaper; normally this is PID 1 / systemd)" : "");
    viewer_print_subtree(getpid(), g_color);

    waitpid(b, NULL, 0);                           /* reap the adopted orphan */
    printf("\n   Adopted orphan reaped. The kernel never leaves a process without a parent.\n");
    close(up[0]);
    close(down[1]);
    return 0;
}
