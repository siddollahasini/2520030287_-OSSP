/*
 * proc.c - CORE: read process information from /proc and build the tree
 *
 *   /proc/<pid>/stat   -> name, state, PPID (parent), thread count
 *   /proc/<pid>/status -> owner UID, resident memory (VmRSS)
 *
 * Parent-child links use first-child / next-sibling lists so that a
 * recursive depth-first walk can print the hierarchy.
 */
#include "ptree.h"

#include <ctype.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int is_number(const char *s) {
    if (!*s) return 0;
    for (; *s; s++) if (!isdigit((unsigned char)*s)) return 0;
    return 1;
}

/* Fill p from /proc/<pid>/... ; returns 0 on success, -1 if the process
 * vanished while we were reading it (normal race, just skip it). */
int read_process(int pid, Proc *p) {
    char path[64], buf[4096];
    FILE *f;

    memset(p, 0, sizeof *p);
    p->pid = pid;
    p->first_child = p->next_sibling = -1;

    /* ---- /proc/<pid>/stat ---- */
    snprintf(path, sizeof path, "/proc/%d/stat", pid);
    f = fopen(path, "r");
    if (!f) return -1;
    size_t n = fread(buf, 1, sizeof buf - 1, f);
    fclose(f);
    if (n == 0) return -1;
    buf[n] = '\0';

    /* The name is inside parentheses and may itself contain spaces or
     * parentheses, so find the FIRST '(' and the LAST ')'. */
    char *lp = strchr(buf, '(');
    char *rp = strrchr(buf, ')');
    if (!lp || !rp || rp < lp) return -1;
    size_t len = (size_t)(rp - lp - 1);
    if (len >= sizeof p->comm) len = sizeof p->comm - 1;
    memcpy(p->comm, lp + 1, len);
    p->comm[len] = '\0';

    /* After ")" the fields are: state ppid pgrp session tty_nr tpgid
     * flags minflt cminflt majflt cmajflt utime stime cutime cstime
     * priority nice num_threads ... */
    if (sscanf(rp + 2,
               "%c %d %*d %*d %*d %*d %*u %*u %*u %*u %*u %*u %*u %*d %*d %*d %*d %ld",
               &p->state, &p->ppid, &p->threads) != 3)
        return -1;

    /* ---- /proc/<pid>/status (owner + memory) ---- */
    snprintf(path, sizeof path, "/proc/%d/status", pid);
    f = fopen(path, "r");
    if (f) {
        char line[256];
        while (fgets(line, sizeof line, f)) {
            unsigned u;
            long kb;
            if (sscanf(line, "Uid: %u", &u) == 1) p->uid = (uid_t)u;
            else if (sscanf(line, "VmRSS: %ld", &kb) == 1) p->rss_kb = kb;
        }
        fclose(f);
    }
    return 0;
}

void snapshot_free(Snapshot *s) {
    free(s->items);
    s->items = NULL;
    s->count = s->cap = 0;
}

static int cmp_pid(const void *a, const void *b) {
    return ((const Proc *)a)->pid - ((const Proc *)b)->pid;
}

/* Binary search: index of pid in a snapshot sorted by pid, or -1. */
int find_pid(const Snapshot *s, int pid) {
    int lo = 0, hi = s->count - 1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        if (s->items[mid].pid == pid) return mid;
        if (s->items[mid].pid < pid) lo = mid + 1; else hi = mid - 1;
    }
    return -1;
}

int snapshot_load(Snapshot *s) {
    DIR *d = opendir("/proc");
    if (!d) { perror("opendir /proc"); return -1; }

    s->count = 0;
    s->cap = 512;
    s->items = malloc(sizeof(Proc) * (size_t)s->cap);
    if (!s->items) { closedir(d); return -1; }

    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (!is_number(e->d_name)) continue;
        if (s->count == s->cap) {
            s->cap *= 2;
            Proc *tmp = realloc(s->items, sizeof(Proc) * (size_t)s->cap);
            if (!tmp) { closedir(d); return -1; }
            s->items = tmp;
        }
        if (read_process(atoi(e->d_name), &s->items[s->count]) == 0)
            s->count++;
    }
    closedir(d);

    qsort(s->items, (size_t)s->count, sizeof(Proc), cmp_pid);
    return 0;
}

/* Link every process to its parent. Children stay sorted by PID because
 * we walk the (already sorted) array and append at the tail. */
void build_tree(Snapshot *s, int *roots, int *nroots) {
    int *last_child = malloc(sizeof(int) * (size_t)(s->count ? s->count : 1));
    for (int i = 0; i < s->count; i++) {
        last_child[i] = -1;
        s->items[i].first_child = s->items[i].next_sibling = -1;
    }

    *nroots = 0;
    for (int i = 0; i < s->count; i++) {
        Proc *p = &s->items[i];
        int parent = (p->ppid > 0) ? find_pid(s, p->ppid) : -1;

        /* kernel thread = pid 2 (kthreadd) or any child of it */
        p->is_kthread = (p->pid == 2 || p->ppid == 2);

        if (parent < 0 || parent == i) {
            roots[(*nroots)++] = i;           /* no parent found -> root */
        } else if (last_child[parent] < 0) {
            s->items[parent].first_child = i;
            last_child[parent] = i;
        } else {
            s->items[last_child[parent]].next_sibling = i;
            last_child[parent] = i;
        }
    }
    free(last_child);
}

void snapshot_stats(const Snapshot *s, Stats *st) {
    memset(st, 0, sizeof *st);
    st->total = s->count;
    for (int i = 0; i < s->count; i++) {
        switch (s->items[i].state) {
            case 'R': st->running++; break;
            case 'Z': st->zombie++;  break;
            case 'T': case 't': st->stopped++; break;
            default:  st->sleeping++; break;
        }
        st->threads += s->items[i].threads;
    }
}
