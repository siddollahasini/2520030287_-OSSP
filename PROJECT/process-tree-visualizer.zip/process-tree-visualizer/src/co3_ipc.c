/*
 * co3_ipc.c - CO3: inter-process communication
 *
 * The tool plays "collector" (child) and "viewer" (parent) and exchanges
 * real process data through every mechanism in the syllabus:
 *   A. anonymous pipe        D. process groups / sessions / job control
 *   B. named pipe (FIFO)     E. POSIX shared memory
 *   C. signals               F. UNIX domain socket
 */
#include "ptree.h"

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <unistd.h>

#define FIFO_PATH "/tmp/ptree_demo.fifo"
#define SOCK_PATH "/tmp/ptree_demo.sock"
#define SHM_NAME  "/ptree_demo_shm"

static void print_stats(const char *how, const Stats *st) {
    printf("   viewer received via %s: %d processes (running %d, sleeping %d, "
           "stopped %d, zombie %d), %ld threads\n", how, st->total, st->running,
           st->sleeping, st->stopped, st->zombie, st->threads);
}

/* ---------------- A. anonymous pipe ---------------- */
static void part_pipe(void) {
    section("A. Anonymous pipe: collector (child) -> viewer (parent)");
    int fd[2];
    if (pipe(fd) < 0) { perror("pipe"); return; }

    pid_t c = safe_fork();
    if (c == 0) {
        close(fd[0]);
        Snapshot s = {0};
        Stats st = {0};
        if (snapshot_load(&s) == 0) snapshot_stats(&s, &st);
        write_full(fd[1], &st, sizeof st);
        _exit(0);
    }
    close(fd[1]);
    Stats st;
    if (read_full(fd[0], &st, sizeof st) == (ssize_t)sizeof st) print_stats("pipe", &st);
    close(fd[0]);
    waitpid(c, NULL, 0);
    printf("   (anonymous pipe: no name, exists only between related processes)\n");
}

/* ---------------- B. named pipe ---------------- */
static void part_fifo(void) {
    section("B. Named pipe (FIFO): child sends the process tree through a file name");
    unlink(FIFO_PATH);
    if (mkfifo(FIFO_PATH, 0600) < 0) { perror("mkfifo"); return; }
    printf("   created FIFO %s (visible in the file system, type 'p')\n", FIFO_PATH);

    pid_t c = safe_fork();
    if (c == 0) {
        int fd = open(FIFO_PATH, O_WRONLY);        /* blocks until a reader opens */
        dup2(fd, STDOUT_FILENO);                   /* stdout now goes into the FIFO */
        close(fd);
        viewer_print_subtree(getppid(), 0);
        fflush(stdout);
        _exit(0);
    }
    int fd = open(FIFO_PATH, O_RDONLY);
    char buf[512];
    ssize_t n;
    printf("   --- text received from the FIFO ---\n");
    fflush(stdout);
    while ((n = read(fd, buf, sizeof buf)) > 0) write_full(STDOUT_FILENO, buf, (size_t)n);
    printf("   --- end ---\n");
    close(fd);
    waitpid(c, NULL, 0);
    unlink(FIFO_PATH);
    printf("   (FIFO persists in the file system until unlinked; unrelated processes can use it)\n");
}

/* ---------------- C. signals ---------------- */
static volatile sig_atomic_t g_sig, g_from;
static void on_sig(int s, siginfo_t *si, void *ctx) { (void)ctx; g_sig = s; g_from = si->si_pid; }

static void part_signals(void) {
    section("C. Signals: asynchronous notifications");

    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = on_sig;
    sa.sa_flags = SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);

    sigset_t block, old;
    sigemptyset(&block);
    sigaddset(&block, SIGUSR1);
    sigprocmask(SIG_BLOCK, &block, &old);          /* avoid losing the signal */

    pid_t c = safe_fork();
    if (c == 0) {
        kill(getppid(), SIGUSR1);                  /* child -> parent notification */
        _exit(0);
    }
    while (!g_sig) sigsuspend(&old);               /* sleep until a signal arrives */
    sigprocmask(SIG_SETMASK, &old, NULL);
    printf("   handler ran: caught signal %d (%s) sent by PID %d (%s)\n", (int)g_sig,
           strsignal(g_sig), (int)g_from, g_from == c ? "our child" : "someone else");
    waitpid(c, NULL, 0);

    /* SIGSTOP / SIGCONT / SIGTERM change the state shown in the tree */
    pid_t sl = safe_fork();
    if (sl == 0) { for (;;) pause(); }
    usleep(100000);
    Proc p;
    kill(sl, SIGSTOP);
    waitpid(sl, NULL, WUNTRACED);
    if (read_process(sl, &p) == 0) printf("   after SIGSTOP : child state = %c (stopped, 'T' in the tree)\n", p.state);
    kill(sl, SIGCONT);
    usleep(100000);
    if (read_process(sl, &p) == 0) printf("   after SIGCONT : child state = %c (sleeping again)\n", p.state);
    kill(sl, SIGTERM);
    int st = 0;
    waitpid(sl, &st, 0);
    if (WIFSIGNALED(st)) printf("   after SIGTERM : child terminated by signal %d (%s)\n",
                                WTERMSIG(st), strsignal(WTERMSIG(st)));
    printf("   (SIGKILL and SIGSTOP cannot be caught; others can have a handler)\n");
}

/* ---------------- D. process groups / sessions ---------------- */
static void part_groups(void) {
    section("D. Process groups, sessions and job control");
    printf("   ptree: PID %d  process-group %d  session %d\n", getpid(), getpgrp(), getsid(0));

    pid_t c = safe_fork();
    if (c == 0) {
        setpgid(0, 0);                             /* become leader of a NEW group */
        for (;;) pause();
    }
    setpgid(c, c);                                 /* parent does it too: avoids a race */
    usleep(50000);
    printf("   child: PID %d  process-group %d  session %d  (own group, same session)\n",
           c, getpgid(c), getsid(c));
    kill(-c, SIGTERM);                             /* negative PID = signal the whole group */
    int st = 0;
    waitpid(c, &st, 0);
    printf("   kill(-%d, SIGTERM) signalled the whole group (this is how Ctrl+C reaches a job)\n", c);
}

/* ---------------- E. shared memory ---------------- */
static void part_shm(void) {
    section("E. POSIX shared memory: collector writes, viewer reads (no copying)");
    shm_unlink(SHM_NAME);
    int fd = shm_open(SHM_NAME, O_CREAT | O_RDWR | O_EXCL, 0600);
    if (fd < 0) { perror("shm_open"); return; }
    IGNORE_RESULT(ftruncate(fd, sizeof(Stats)));
    close(fd);

    pid_t c = safe_fork();
    if (c == 0) {
        int f = shm_open(SHM_NAME, O_RDWR, 0);     /* attach by NAME */
        Stats *shared = mmap(NULL, sizeof(Stats), PROT_READ | PROT_WRITE, MAP_SHARED, f, 0);
        Snapshot s = {0};
        Stats st = {0};
        if (snapshot_load(&s) == 0) snapshot_stats(&s, &st);
        *shared = st;                              /* plain memory write */
        _exit(0);
    }
    waitpid(c, NULL, 0);                           /* simple synchronisation */
    int f = shm_open(SHM_NAME, O_RDONLY, 0);
    Stats *shared = mmap(NULL, sizeof(Stats), PROT_READ, MAP_SHARED, f, 0);
    print_stats("shared memory", shared);
    printf("   (visible as /dev/shm%s while it exists; fastest IPC - needs synchronisation)\n", SHM_NAME);
    munmap(shared, sizeof(Stats));
    close(f);
    shm_unlink(SHM_NAME);
}

/* ---------------- F. UNIX domain socket ---------------- */
static void part_socket(void) {
    section("F. UNIX domain socket: viewer asks the collector \"who is PID n?\"");
    int srv = socket(AF_UNIX, SOCK_STREAM, 0);
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof addr);
    addr.sun_family = AF_UNIX;
    snprintf(addr.sun_path, sizeof addr.sun_path, "%s", SOCK_PATH);
    unlink(SOCK_PATH);
    if (bind(srv, (struct sockaddr *)&addr, sizeof addr) < 0 || listen(srv, 1) < 0) {
        perror("bind/listen");
        close(srv);
        return;
    }

    pid_t c = safe_fork();
    if (c == 0) {                                  /* ---- server (collector) ---- */
        int conn = accept(srv, NULL, NULL);
        char req[64] = {0}, rep[160];
        ssize_t n = read(conn, req, sizeof req - 1);
        int pid = (n > 4 && !strncmp(req, "WHO ", 4)) ? atoi(req + 4) : 0;
        Proc p;
        if (pid > 0 && read_process(pid, &p) == 0)
            snprintf(rep, sizeof rep, "PID %d is '%s', parent PID %d, state %c\n", p.pid, p.comm, p.ppid, p.state);
        else
            snprintf(rep, sizeof rep, "unknown PID\n");
        write_full(conn, rep, strlen(rep));
        close(conn);
        _exit(0);
    }
    close(srv);

    int cl = socket(AF_UNIX, SOCK_STREAM, 0);     /* ---- client (viewer) ---- */
    if (connect(cl, (struct sockaddr *)&addr, sizeof addr) < 0) { perror("connect"); }
    else {
        char req[64], rep[160] = {0};
        snprintf(req, sizeof req, "WHO %d", getpid());
        printf("   viewer -> collector: \"%s\"\n", req);
        write_full(cl, req, strlen(req));
        ssize_t n = read(cl, rep, sizeof rep - 1);
        if (n > 0) printf("   collector -> viewer: %s", rep);
    }
    close(cl);
    waitpid(c, NULL, 0);
    unlink(SOCK_PATH);
    printf("   (two-way, works between unrelated processes, address is a file path)\n");
}

int co3_ipc(void) {
    banner("CO3", "Inter-process communication");
    part_pipe();
    part_fifo();
    part_signals();
    part_groups();
    part_shm();
    part_socket();
    return 0;
}
