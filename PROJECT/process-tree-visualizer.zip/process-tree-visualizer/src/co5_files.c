/*
 * co5_files.c - CO5: file systems and file I/O
 *
 *   --files [PID]  open file descriptors of a process and their inodes
 *   --fs-demo      inodes, hard/soft links, lseek, directory entries,
 *                  mount points, buffered vs unbuffered I/O, mmap I/O,
 *                  robust error handling
 *   --save / --load  store a process snapshot as a structured binary file
 *                  and replay it later (open/write/read/fstat, validation)
 *
 * Also holds the small robust-I/O helpers used by every other module.
 */
#include "ptree.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

/* ------------------------------------------------------------------ */
/* robust I/O helpers                                                  */
/* ------------------------------------------------------------------ */
/* write() may write fewer bytes than asked, or be interrupted by a signal. */
ssize_t write_full(int fd, const void *buf, size_t n) {
    const char *p = buf;
    size_t left = n;
    while (left > 0) {
        ssize_t w = write(fd, p, left);
        if (w < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        p += w;
        left -= (size_t)w;
    }
    return (ssize_t)n;
}

/* read() may return fewer bytes than asked (pipes, sockets): loop until done or EOF. */
ssize_t read_full(int fd, void *buf, size_t n) {
    char *p = buf;
    size_t got = 0;
    while (got < n) {
        ssize_t r = read(fd, p + got, n - got);
        if (r < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (r == 0) break;
        got += (size_t)r;
    }
    return (ssize_t)got;
}

/* Flush stdio before fork so buffered text is not duplicated in the child. */
pid_t safe_fork(void) {
    fflush(NULL);
    return fork();
}

static const char *type_name(mode_t m) {
    if (S_ISREG(m))  return "file";
    if (S_ISDIR(m))  return "dir";
    if (S_ISCHR(m))  return "chardev";
    if (S_ISBLK(m))  return "blockdev";
    if (S_ISFIFO(m)) return "pipe/fifo";
    if (S_ISSOCK(m)) return "socket";
    if (S_ISLNK(m))  return "symlink";
    return "?";
}

/* ------------------------------------------------------------------ */
/* --files : descriptor table -> open file description -> inode        */
/* ------------------------------------------------------------------ */
int co5_files(int pid) {
    banner("CO5", "File descriptors and inodes of a process (VFS view)");
    if (pid <= 0) pid = getpid();
    Proc p;
    if (read_process(pid, &p) != 0) { printf("   PID %d not found\n", pid); return 1; }

    char dir[64];
    snprintf(dir, sizeof dir, "/proc/%d/fd", pid);
    DIR *d = opendir(dir);
    if (!d) { printf("   cannot open %s: %s\n", dir, strerror(errno)); return 1; }

    printf("   process %d (%s)\n", pid, p.comm);
    printf("   %-4s %-10s %-10s %-9s %-8s %s\n", "FD", "TYPE", "INODE", "DEV", "OFFSET", "TARGET");

    struct dirent *e;
    int shown = 0;
    while ((e = readdir(d)) != NULL) {
        if (e->d_name[0] < '0' || e->d_name[0] > '9') continue;
        char lp[320], target[256] = "", info[320];
        snprintf(lp, sizeof lp, "%s/%s", dir, e->d_name);
        ssize_t n = readlink(lp, target, sizeof target - 1);
        if (n > 0) target[n] = '\0'; else target[0] = '\0';

        struct stat st;
        if (stat(lp, &st) != 0) memset(&st, 0, sizeof st);

        long pos = -1;
        snprintf(info, sizeof info, "/proc/%d/fdinfo/%s", pid, e->d_name);
        FILE *f = fopen(info, "r");
        if (f) {
            char line[128];
            while (fgets(line, sizeof line, f)) if (sscanf(line, "pos: %ld", &pos) == 1) break;
            fclose(f);
        }
        char dev[16];
        snprintf(dev, sizeof dev, "%u:%u", major(st.st_dev), minor(st.st_dev));
        printf("   %-4s %-10s %-10lu %-9s %-8ld %s\n", e->d_name, type_name(st.st_mode),
               (unsigned long)st.st_ino, dev, pos, target);
        shown++;
    }
    closedir(d);
    printf("\n   FD 0,1,2 = stdin, stdout, stderr. Each FD is an index in the process's\n"
           "   descriptor table -> open file description (offset, flags) -> inode.\n"
           "   Two FDs with the same inode+device refer to the same underlying file.\n");
    return shown ? 0 : 1;
}

/* ------------------------------------------------------------------ */
/* --fs-demo                                                           */
/* ------------------------------------------------------------------ */
typedef struct { int id; char name[28]; double value; } Rec;   /* 40-byte record */

static double now_s(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

static void print_mount_for(const char *path) {
    char real[PATH_MAX];
    if (!realpath(path, real)) return;
    FILE *f = fopen("/proc/self/mountinfo", "r");
    if (!f) return;
    char line[1024], best_mp[256] = "", best_fs[64] = "", best_src[256] = "";
    while (fgets(line, sizeof line, f)) {
        /* id parent maj:min root mountpoint opts [optional...] - fstype source superopts */
        char mp[256], fst[64], src[256];
        char *dash = strstr(line, " - ");
        if (!dash) continue;
        if (sscanf(line, "%*d %*d %*s %*s %255s", mp) != 1) continue;
        if (sscanf(dash + 3, "%63s %255s", fst, src) < 1) continue;
        size_t l = strlen(mp);
        if (!strncmp(real, mp, l) && (real[l] == '/' || real[l] == '\0' || l == 1) &&
            l >= strlen(best_mp)) {
            snprintf(best_mp, sizeof best_mp, "%s", mp);
            snprintf(best_fs, sizeof best_fs, "%s", fst);
            snprintf(best_src, sizeof best_src, "%s", src);
        }
    }
    fclose(f);
    printf("   %s lives on mount point '%s', file-system type '%s' (source %s)\n",
           real, best_mp, best_fs, best_src);
}

int co5_fs_demo(void) {
    banner("CO5", "File-system abstractions and file I/O system calls");
    const char *dir = "/tmp/ptree_fs_demo";
    char f1[128], hard[128], soft[128], big[128];
    snprintf(f1, sizeof f1, "%s/records.dat", dir);
    snprintf(hard, sizeof hard, "%s/hardlink.dat", dir);
    snprintf(soft, sizeof soft, "%s/symlink.dat", dir);
    snprintf(big, sizeof big, "%s/io_test.dat", dir);
    unlink(f1); unlink(hard); unlink(soft); unlink(big);
    if (mkdir(dir, 0755) < 0 && errno != EEXIST) { perror("mkdir"); return 1; }

    /* ---- 1. create + write structured data ---- */
    section("1. open(O_CREAT) + write(): store fixed-size records");
    int fd = open(f1, O_CREAT | O_TRUNC | O_RDWR, 0644);
    if (fd < 0) { perror("open"); return 1; }
    const char *names[] = { "init", "sshd", "bash", "ptree", "firefox" };
    for (int i = 0; i < 5; i++) {
        Rec r;
        memset(&r, 0, sizeof r);
        r.id = i; r.value = 1.5 * (i + 1);
        snprintf(r.name, sizeof r.name, "%s", names[i]);
        if (write_full(fd, &r, sizeof r) < 0) { perror("write"); return 1; }
    }
    printf("   file descriptor returned by open() = %d; wrote 5 records x %zu bytes\n", fd, sizeof(Rec));

    /* ---- 2. random access ---- */
    section("2. lseek() + read(): random access");
    Rec r;
    off_t pos = lseek(fd, 3 * (off_t)sizeof r, SEEK_SET);
    read_full(fd, &r, sizeof r);
    printf("   lseek to byte %ld, read record #3 -> id=%d name=%s value=%.1f\n", (long)pos, r.id, r.name, r.value);
    printf("   current offset = %ld, file size (SEEK_END) = %ld bytes\n",
           (long)lseek(fd, 0, SEEK_CUR), (long)lseek(fd, 0, SEEK_END));

    /* ---- 3. inode ---- */
    section("3. fstat(): the inode holds everything except the file name");
    struct stat st;
    fstat(fd, &st);
    printf("   inode=%lu  size=%ld  blocks(512B)=%ld  links=%lu  mode=%o  uid=%u  device=%u:%u\n",
           (unsigned long)st.st_ino, (long)st.st_size, (long)st.st_blocks,
           (unsigned long)st.st_nlink, st.st_mode & 0777, st.st_uid, major(st.st_dev), minor(st.st_dev));
    close(fd);

    /* ---- 4. links ---- */
    section("4. Directory entries: hard link vs symbolic link");
    IGNORE_RESULT(link(f1, hard));
    IGNORE_RESULT(symlink(f1, soft));
    struct stat a, b, c;
    stat(f1, &a); stat(hard, &b); lstat(soft, &c);
    printf("   records.dat   inode %lu, link count %lu\n", (unsigned long)a.st_ino, (unsigned long)a.st_nlink);
    printf("   hardlink.dat  inode %lu  -> %s inode (second NAME for the same file)\n",
           (unsigned long)b.st_ino, a.st_ino == b.st_ino ? "SAME" : "different");
    printf("   symlink.dat   inode %lu  -> %s inode (a tiny separate file holding a path, type %s)\n",
           (unsigned long)c.st_ino, a.st_ino == c.st_ino ? "same" : "DIFFERENT", type_name(c.st_mode));

    section("5. readdir(): a directory is a table of (name -> inode)");
    DIR *d = opendir(dir);
    struct dirent *e;
    while (d && (e = readdir(d)) != NULL)
        printf("   inode %-8lu type %-8s %s\n", (unsigned long)e->d_ino,
               e->d_type == DT_REG ? "file" : e->d_type == DT_DIR ? "dir" : e->d_type == DT_LNK ? "symlink" : "other",
               e->d_name);
    if (d) closedir(d);

    section("6. Mount point / file-system type (VFS hides the differences)");
    print_mount_for(dir);

    /* ---- 7. buffered vs unbuffered ---- */
    section("7. Unbuffered write() vs buffered fwrite() for 100,000 small records");
    enum { N = 100000 };
    char rec16[16];
    memset(rec16, 'x', sizeof rec16);

    int ufd = open(big, O_CREAT | O_TRUNC | O_WRONLY, 0644);
    double t0 = now_s();
    for (int i = 0; i < N; i++) IGNORE_RESULT(write(ufd, rec16, sizeof rec16));
    double t1 = now_s();
    close(ufd);

    FILE *bf = fopen(big, "w");
    for (int i = 0; i < N; i++) fwrite(rec16, 1, sizeof rec16, bf);
    fclose(bf);
    double t2 = now_s();
    printf("   write()  : %6.1f ms, %d system calls\n", (t1 - t0) * 1000, N);
    printf("   fwrite() : %6.1f ms, about %d system calls (stdio collects data in a 4 KB buffer)\n",
           (t2 - t1) * 1000, (int)((long)N * 16 / 4096) + 1);

    /* ---- 8. mmap ---- */
    section("8. Memory-mapped file I/O: edit a file like an array");
    fd = open(f1, O_RDWR);
    Rec *map = mmap(NULL, 5 * sizeof(Rec), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (map != MAP_FAILED) {
        printf("   before: record #1 value = %.1f\n", map[1].value);
        map[1].value = 99.5;                          /* ordinary memory write */
        msync(map, 5 * sizeof(Rec), MS_SYNC);
        Rec check;
        IGNORE_RESULT(pread(fd, &check, sizeof check, (off_t)sizeof(Rec)));
        printf("   after map[1].value = 99.5 and msync(): pread() sees %.1f (page cache is shared)\n", check.value);
        munmap(map, 5 * sizeof(Rec));
    }
    close(fd);

    /* ---- 9. robust error handling ---- */
    section("9. Robust file handling: always check errors");
    if (open("/tmp/ptree_fs_demo/does_not_exist", O_RDONLY) < 0)
        printf("   open(missing file)        -> errno %d: %s\n", errno, strerror(errno));
    fd = open(f1, O_RDONLY);
    if (write(fd, "x", 1) < 0)
        printf("   write() on read-only FD   -> errno %d: %s\n", errno, strerror(errno));
    close(fd);
    printf("   (partial reads/writes and EINTR are handled by write_full()/read_full())\n");

    unlink(f1); unlink(hard); unlink(soft); unlink(big);
    rmdir(dir);
    printf("\n   demo files removed.\n");
    return 0;
}

/* ------------------------------------------------------------------ */
/* --save / --load : structured binary snapshot file                   */
/* ------------------------------------------------------------------ */
typedef struct {
    char     magic[8];       /* "PTREESNP"                       */
    uint32_t version;
    uint32_t count;          /* number of records that follow    */
    int64_t  timestamp;
} SnapHeader;                /* 24 bytes */

typedef struct {
    int32_t  pid;
    int32_t  ppid;
    uint32_t uid;
    char     state;
    char     pad[3];
    int64_t  rss_kb;
    int64_t  threads;
    char     comm[64];
} SnapRecord;                /* 96 bytes, no hidden padding */

_Static_assert(sizeof(SnapHeader) == 24, "header layout");
_Static_assert(sizeof(SnapRecord) == 96, "record layout");

int co5_save(const char *path) {
    Snapshot s = {0};
    if (snapshot_load(&s) != 0) return 1;
    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) { fprintf(stderr, "cannot create %s: %s\n", path, strerror(errno)); snapshot_free(&s); return 1; }

    SnapHeader h;
    memset(&h, 0, sizeof h);
    memcpy(h.magic, "PTREESNP", 8);
    h.version = 1;
    h.count = (uint32_t)s.count;
    h.timestamp = (int64_t)time(NULL);
    int ok = write_full(fd, &h, sizeof h) == (ssize_t)sizeof h;

    for (int i = 0; ok && i < s.count; i++) {
        SnapRecord r;
        memset(&r, 0, sizeof r);
        r.pid = s.items[i].pid;  r.ppid = s.items[i].ppid;  r.uid = s.items[i].uid;
        r.state = s.items[i].state;  r.rss_kb = s.items[i].rss_kb;  r.threads = s.items[i].threads;
        snprintf(r.comm, sizeof r.comm, "%s", s.items[i].comm);
        ok = write_full(fd, &r, sizeof r) == (ssize_t)sizeof r;
    }
    if (close(fd) != 0) ok = 0;                     /* close() can report write errors */
    if (!ok) { fprintf(stderr, "write error: %s\n", strerror(errno)); snapshot_free(&s); return 1; }

    printf("Saved %d processes to %s (%zu bytes: 24-byte header + %d x %zu-byte records)\n",
           s.count, path, sizeof h + (size_t)s.count * sizeof(SnapRecord), s.count, sizeof(SnapRecord));
    printf("Replay later with:  ./ptree --load %s\n", path);
    snapshot_free(&s);
    return 0;
}

int co5_load(const char *path) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) { fprintf(stderr, "cannot open %s: %s\n", path, strerror(errno)); return 1; }

    struct stat st;
    SnapHeader h;
    if (fstat(fd, &st) != 0 || read_full(fd, &h, sizeof h) != (ssize_t)sizeof h ||
        memcmp(h.magic, "PTREESNP", 8) != 0 || h.version != 1) {
        fprintf(stderr, "%s is not a valid ptree snapshot file\n", path);
        close(fd);
        return 1;
    }
    /* never trust the count: it must match the real file size */
    if ((off_t)(sizeof h + (size_t)h.count * sizeof(SnapRecord)) != st.st_size) {
        fprintf(stderr, "%s is corrupt or truncated (size does not match record count)\n", path);
        close(fd);
        return 1;
    }

    Snapshot s = {0};
    s.cap = s.count = (int)h.count;
    s.items = calloc(h.count ? h.count : 1, sizeof(Proc));
    for (int i = 0; i < s.count; i++) {
        SnapRecord r;
        if (read_full(fd, &r, sizeof r) != (ssize_t)sizeof r) { fprintf(stderr, "short read\n"); close(fd); snapshot_free(&s); return 1; }
        Proc *p = &s.items[i];
        p->pid = r.pid;  p->ppid = r.ppid;  p->uid = r.uid;  p->state = r.state;
        p->rss_kb = r.rss_kb;  p->threads = r.threads;
        p->first_child = p->next_sibling = -1;
        r.comm[sizeof r.comm - 1] = '\0';
        snprintf(p->comm, sizeof p->comm, "%s", r.comm);
    }
    close(fd);

    char ts[32];
    time_t t = (time_t)h.timestamp;
    strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S", localtime(&t));
    printf("Replaying snapshot taken at %s (%u processes)\n", ts, h.count);
    g_opt.once = 1;
    viewer_render(&s, NULL, 0, 40);
    snapshot_free(&s);
    return 0;
}
