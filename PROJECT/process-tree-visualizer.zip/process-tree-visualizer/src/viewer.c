/*
 * viewer.c - CORE: draws the process tree in the terminal
 */
#include "ptree.h"

#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define C_RESET   "\033[0m"
#define C_BOLD    "\033[1m"
#define C_DIM     "\033[2m"
#define C_RED     "\033[31m"
#define C_GREEN   "\033[32m"
#define C_YELLOW  "\033[33m"
#define C_BLUE    "\033[34m"
#define C_MAGENTA "\033[35m"
#define C_CYAN    "\033[36m"

Options g_opt;
int     g_color;

static int g_lines_left;     /* screen lines still available */
static int g_hidden;         /* lines that did not fit       */

static const char *col(const char *c) { return g_color ? c : ""; }

static const char *state_color(char st) {
    switch (st) {
        case 'R': return C_GREEN;
        case 'D': return C_YELLOW;
        case 'Z': return C_RED;
        case 'T': case 't': return C_MAGENTA;
        default:  return C_DIM;      /* S, I, ... */
    }
}

static const char *state_name(char st) {
    switch (st) {
        case 'R': return "running";
        case 'S': return "sleeping";
        case 'D': return "disk-wait";
        case 'Z': return "zombie";
        case 'T': return "stopped";
        case 't': return "tracing";
        case 'I': return "idle";
        default:  return "other";
    }
}

static const char *user_of(uid_t uid, char *buf, size_t n) {
    struct passwd *pw = getpwuid(uid);
    if (pw) snprintf(buf, n, "%s", pw->pw_name);
    else    snprintf(buf, n, "%u", (unsigned)uid);
    return buf;
}

static int visible(const Snapshot *s, int idx) {
    return !(g_opt.hide_kthreads && s->items[idx].is_kthread);
}

static void print_node(const Snapshot *s, int idx, const char *prefix,
                       int is_last, int is_root, int depth) {
    const Proc *p = &s->items[idx];

    if (g_lines_left <= 0) { g_hidden++; }
    else {
        char ubuf[32], mem[32];
        if (p->rss_kb >= 1024) snprintf(mem, sizeof mem, "%.1fMB", p->rss_kb / 1024.0);
        else                   snprintf(mem, sizeof mem, "%ldKB", p->rss_kb);

        printf("%s%s", prefix, is_root ? "" : (is_last ? "└── " : "├── "));
        if (p->is_new) printf("%s+%s", col(C_BOLD C_GREEN), col(C_RESET));
        printf("%s%s%s (%d) ", col(C_BOLD), p->comm, col(C_RESET), p->pid);
        printf("%s[%c %s]%s ", col(state_color(p->state)), p->state,
               state_name(p->state), col(C_RESET));
        printf("%s%s%s  %s%s%s  thr:%ld\n",
               col(C_CYAN), user_of(p->uid, ubuf, sizeof ubuf), col(C_RESET),
               col(C_BLUE), mem, col(C_RESET), p->threads);
        g_lines_left--;
    }

    if (g_opt.max_depth && depth + 1 >= g_opt.max_depth) return;

    char child_prefix[1024];
    snprintf(child_prefix, sizeof child_prefix, "%s%s", prefix,
             is_root ? "" : (is_last ? "    " : "│   "));

    /* find last visible child so we can draw └── correctly */
    int last_vis = -1;
    for (int c = p->first_child; c >= 0; c = s->items[c].next_sibling)
        if (visible(s, c)) last_vis = c;

    for (int c = p->first_child; c >= 0; c = s->items[c].next_sibling)
        if (visible(s, c))
            print_node(s, c, child_prefix, c == last_vis, 0, depth + 1);
}

static void print_summary(const Snapshot *s) {
    Stats st;
    snapshot_stats(s, &st);
    time_t now = time(NULL);
    char ts[32];
    strftime(ts, sizeof ts, "%H:%M:%S", localtime(&now));

    printf("%s%sLinux Process Tree Visualizer%s   %s\n", col(C_BOLD), col(C_CYAN),
           col(C_RESET), ts);
    printf("Processes: %d   %srunning:%d%s  sleeping/other:%d  %sstopped:%d%s  %szombie:%d%s  threads:%ld\n\n",
           st.total, col(C_GREEN), st.running, col(C_RESET), st.sleeping,
           col(C_MAGENTA), st.stopped, col(C_RESET), col(C_RED), st.zombie,
           col(C_RESET), st.threads);
}

void viewer_render(Snapshot *cur, const Snapshot *prev, int have_prev, int rows) {
    /* mark new processes */
    if (have_prev)
        for (int i = 0; i < cur->count; i++)
            cur->items[i].is_new = (find_pid(prev, cur->items[i].pid) < 0);

    int *roots = malloc(sizeof(int) * (size_t)(cur->count ? cur->count : 1));
    int nroots;
    build_tree(cur, roots, &nroots);

    print_summary(cur);

    /* leave room for header + exited list + footer */
    g_lines_left = g_opt.once ? 1 << 30 : (rows > 10 ? rows - 8 : 10);
    g_hidden = 0;

    if (g_opt.root_pid) {
        int r = find_pid(cur, g_opt.root_pid);
        if (r < 0) printf("PID %d not found.\n", g_opt.root_pid);
        else       print_node(cur, r, "", 1, 1, 0);
    } else {
        for (int i = 0; i < nroots; i++) {
            if (!visible(cur, roots[i])) continue;
            print_node(cur, roots[i], "", 1, 1, 0);
        }
    }
    if (g_hidden)
        printf("%s... %d more lines (terminal too small; use -d, -p, -k to narrow)%s\n",
               col(C_DIM), g_hidden, col(C_RESET));

    /* processes that exited since last refresh */
    if (have_prev) {
        int shown = 0;
        for (int i = 0; i < prev->count; i++) {
            if (find_pid(cur, prev->items[i].pid) >= 0) continue;
            if (!shown++) printf("\n%sExited:%s ", col(C_RED), col(C_RESET));
            if (shown <= 8)
                printf("%s%s(%d)%s ", col(C_RED), prev->items[i].comm,
                       prev->items[i].pid, col(C_RESET));
        }
        if (shown > 8) printf("%s... +%d more%s", col(C_RED), shown - 8, col(C_RESET));
        if (shown) printf("\n");
    }
    free(roots);
}

/* Print only the subtree of one PID from a FRESH snapshot (used by demos). */
void viewer_print_subtree(int pid, int color) {
    Snapshot s = {0};
    if (snapshot_load(&s) != 0) return;
    int *roots = malloc(sizeof(int) * (size_t)(s.count ? s.count : 1));
    int nroots;
    build_tree(&s, roots, &nroots);

    int saved_color = g_color;
    g_color = color;
    g_lines_left = 1 << 30;
    g_hidden = 0;

    int r = find_pid(&s, pid);
    if (r < 0) printf("    (PID %d not found - already exited)\n", pid);
    else       print_node(&s, r, "    ", 1, 1, 0);

    g_color = saved_color;
    free(roots);
    snapshot_free(&s);
}

void banner(const char *co, const char *title) {
    printf("\n%s================================================================\n"
           " %s : %s\n"
           "================================================================%s\n",
           col(C_BOLD C_CYAN), co, title, col(C_RESET));
}

void section(const char *text) {
    printf("\n%s-- %s%s\n", col(C_BOLD C_YELLOW), text, col(C_RESET));
}
